module.exports = {
	entry: ["./index", "./index2"]
};
