module.exports = function() {
	return "This is page A.";
};