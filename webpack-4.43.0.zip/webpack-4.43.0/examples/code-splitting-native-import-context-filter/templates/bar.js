var bar = "bar";

export default bar;
