# example.js

```javascript
_{{example.js}}_
```

# dist/output.js

```javascript
_{{dist/output.js}}_
```

# dist/1.output.js

```javascript
_{{dist/1.output.js}}_
```

# dist/2.output.js

```javascript
_{{dist/2.output.js}}_
```

# Info

## Unoptimized

```
_{{stdout}}_
```

## Production mode

```
_{{production:stdout}}_
```
