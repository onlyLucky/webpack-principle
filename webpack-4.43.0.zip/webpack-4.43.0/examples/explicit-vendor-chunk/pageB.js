console.log(require("./vendor2"));
module.exports = "pageB";