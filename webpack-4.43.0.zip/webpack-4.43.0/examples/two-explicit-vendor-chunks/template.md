# webpack.config.js

```javascript
_{{webpack.config.js}}_
```

# dist/vendor1.js

```javascript
_{{dist/vendor1.js}}_
```

# dist/vendor2.js

```javascript
_{{dist/vendor2.js}}_
```

# dist/pageA.js

```javascript
_{{dist/pageA.js}}_
```

# Info

## Unoptimized

```
_{{stdout}}_
```

## Production mode

```
_{{production:stdout}}_
```
