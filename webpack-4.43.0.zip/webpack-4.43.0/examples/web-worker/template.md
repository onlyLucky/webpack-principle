# example.js

```javascript
_{{example.js}}_
```

# worker.js

```javascript
_{{worker.js}}_
```

# dist/output.js

```javascript
_{{dist/output.js}}_
```

# dist/[hash].worker.js

```javascript
_{{dist/hash.worker.js}}_
```

# dist/1.[hash].worker.js

```javascript
_{{dist/1.hash.worker.js}}_
```

# Info

## Unoptimized

```
_{{stdout}}_
```

## Production mode

```
_{{production:stdout}}_
```
