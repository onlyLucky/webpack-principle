// module b
export function b() {
	return "b";
}
