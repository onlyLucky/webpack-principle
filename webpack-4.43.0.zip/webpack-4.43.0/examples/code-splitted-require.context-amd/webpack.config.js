module.exports = {
	optimization: {
		occurrenceOrder: true // To keep filename consistent between different modes (for example building only)
	}
};
