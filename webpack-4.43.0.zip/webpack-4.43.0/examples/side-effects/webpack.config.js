module.exports = {
	optimization: {
		sideEffects: true
	}
};
