# webpack.config.js

```javascript
_{{webpack.config.js}}_
```

# dist/MyLibrary.umd.js

```javascript
_{{dist/MyLibrary.umd.js}}_
```

# Info

## Unoptimized

```
_{{stdout}}_
```

## Production mode

```
_{{production:stdout}}_
```
